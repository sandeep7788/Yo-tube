package com.downloder.savefromyotube;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import at.huber.youtubeExtractor.YouTubeUriExtractor;
import at.huber.youtubeExtractor.YtFile;

public class Downloder extends AppCompatActivity {
    private int RC_SIGN_IN = 2;
    String WritePermission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    String ReadPermission = Manifest.permission.READ_EXTERNAL_STORAGE;
    Button b1,b2,b3,b4;
    EditText e1;
    ProgressDialog progress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloder);
        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
        e1=findViewById(R.id.e1);
        progress = new ProgressDialog(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        progress.setMessage("Downloading Video :) ");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setCancelable(false);

        if (ActivityCompat.checkSelfPermission(this, WritePermission) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, ReadPermission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{WritePermission, ReadPermission}, 1);
        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ytvdownload(18);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ytvdownload(22);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ytvdownload(140);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ytvdownload(251);
//                ytvdownload(140);
            }
        });

    }

    public void ytvdownload(int value) {
        if(e1.getText().toString().isEmpty())
        {
            Toast.makeText(this, "Please Enter Yo-tube URL", Toast.LENGTH_SHORT).show();
        }
        else {
            if (e1.getText().toString().contains("http")) {
                YouTubeVideoDownloadF(value);
                progress.show();
            }
            else Toast.makeText(this,"Please Enter Valid URL First",Toast.LENGTH_LONG).show();
        }
    }

    public void YouTubeVideoDownloadF(int iTag){

        if (ActivityCompat.checkSelfPermission(this, WritePermission) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, ReadPermission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{WritePermission, ReadPermission}, 1);
            progress.dismiss();
        } else {
            progress.dismiss();
            YTDownload(iTag);
        }
    }

    public void YTDownload(final int itag) {
        String VideoURLDownload = e1.getText().toString();
        @SuppressLint("StaticFieldLeak") YouTubeUriExtractor youTubeUriExtractor = new YouTubeUriExtractor(this) {
            @Override
            public void onUrisAvailable(String videoId, String videoTitle, SparseArray<YtFile> ytFiles) {
                progress.dismiss();
                try
                {
                    if ((ytFiles != null)) {
                        String downloadURL = ytFiles.get(itag).getUrl();
                        Log.e("Download URL: ", downloadURL);
                        if(itag==18 || itag == 22) {
                            String mp4=".mp4";
                            DownloadManagingF(downloadURL, videoTitle,mp4);
                        }else if (itag == 251){
                            String mp3=".mp3";
                            DownloadManagingF(downloadURL,videoTitle,mp3);
                        }

                    } else Toast.makeText(Downloder.this, "Error With URL", Toast.LENGTH_LONG).show();
                    progress.dismiss();
                }
                catch (Exception e)
                {
                    Toast.makeText(Downloder.this, "Error With URL", Toast.LENGTH_LONG).show();
                }

            }


        };
        youTubeUriExtractor.execute(VideoURLDownload);
    }

    public void DownloadManagingF(String downloadURL, String videoTitle,String extentiondwn){
        if (downloadURL != null) {
            DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadURL));
            request.setTitle(videoTitle);
            request.setDestinationInExternalPublicDir("/Download/Yo-Tube-Downloader/", videoTitle + extentiondwn);
            if (downloadManager != null) {
                Toast.makeText(getApplicationContext(),"Downloading...",Toast.LENGTH_LONG).show();
                downloadManager.enqueue(request);
            }
            BroadcastReceiver onComplete = new BroadcastReceiver() {
                public void onReceive(Context ctxt, Intent intent) {
                    Toast.makeText(getApplicationContext(),"Download Completed",Toast.LENGTH_SHORT).show();

                    Uri selectedUri = Uri.parse(Environment.getExternalStorageDirectory() + "/Download/YouTube-Downloader/");
                    Intent intentop = new Intent(Intent.ACTION_VIEW);
                    intentop.setDataAndType(selectedUri, "resource/folder");

                    if (intentop.resolveActivityInfo(getPackageManager(), 0) != null)
                    {
                        startActivity(intentop);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Saved on: Download/YouTube-Downloader",Toast.LENGTH_LONG).show();
                        restartApp();
                    }
                    unregisterReceiver(this);
                    finish();
                }
            };
            registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        }
    }
    public void restartApp() {
        Intent i = new Intent(getApplicationContext(),MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
}